#Written by Ajay Das PhD_CSE (de.ci.phe.red Lab, IIT Bhilai)
#We have define miniAES in which follows SB-->SR-->MC-->AddRKey till 4 round and the last round does not include mix-column operation
#Output should be read column wise
#The test vector is given for only 5 round miniAES
#Change Plaintext and Key given in test vector and see the corresponding ciphertext

################################    MINI AES  #################################

import numpy as np

class miniAES_Encrypt:

    def __init__(self, state):
        self.state = state
        self.sbox = [14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7]
        self.rc = [1, 2, 4, 8, 3, 6, 12, 11, 5, 10]


    def keySchedule(self, key):
        genkey = []
        for i in range(10):
            a = []
            k = key[3] #extract 4th nibble
            k = self.sbox[k] # sbox operation
            k = k ^ self.rc[i] #add round constant
            for j in range(4):
                k = k ^ key[j]
                a.append(k)
            key = a
            #print(key)
            genkey.append(a)
        #print(genkey)

        # Break the original list into a list of lists
        out = []
        for i in range(10):
            original_list = genkey[i]
            #result = [original_list[i:i+2] for i in range(0, len(original_list), 2)]
            original_list = [[original_list[i], original_list[i+1]] for i in range(0, len(original_list), 2)]
            # Transpose the original list
            result = [[row[i] for row in original_list] for i in range(len(original_list[0]))]

            out.append(result)
        return out
        


    #shift row operation
    def shiftRows(self):
        temp = []
        for i in range(0, 2):
            shift_row = self.state[i][i:] + self.state[i][:i]
            temp.append(shift_row)
        self.state = temp
        return self.state
    

    #subBytes operation (Pass through S-Box)
    def sub_bytes(self):
        for i in range(2):
            for j in range(2):
                self.state[i][j] = self.sbox[self.state[i][j]]
        return self.state
    
    # Add Round Key
    def add_round_key(self, round_key):
        for i in range(2):
            for j in range(2):
                self.state[i][j] ^= round_key[i][j]
        return self.state
    

    def mix_column(self):
        mix_matrix = np.array([
            [3, 2],
            [2, 3]
        ])
        result = np.zeros((2, 2), dtype=np.uint8)
        #print(result)
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    result[i][j] ^= self.gf_mult(mix_matrix[i][k], self.state[k][j])
                result[i][j] %= 16

        temp = []
        for i in range(0, 2):
            temp.append(list(result[i]))

        self.state = temp
        return self.state
    
    # Galois Field Multiplication
    def gf_mult(self, a, b):
        p = 0
        for _ in range(4):
            if b & 1:
                p ^= a
            hi_bit_set = a & 0x8
            a <<= 1
            if hi_bit_set:
                a ^= 0x13   #irrdicible x^4 + x + 1
            b >>= 1
        return p
    

state = [[0, 0], [0, 0]]
#state = [[1, 2], [3, 4]]
obj = miniAES_Encrypt(state)


key = [0,0,0,0] #initial key passed
print("Round keys are :")
print(obj.keySchedule(key)) #Printing round keys in the for of 2D list of list 
print()

#Printing round keys for each round
for i in obj.keySchedule(key):
    print(i)
keys = obj.keySchedule(key)

print("\n")
print('-' * 100)

#Add initial key (ignore for miniAES)
#state = obj.add_round_key(keys[0])
#capturing ciphertext after 5 rounds
for i in range(0, 4):
    #print('Key', keys[i])
    print(state)
    state = obj.sub_bytes()
    print(state)
    state = obj.shiftRows()
    print(state)
    state = obj.mix_column()
    print(state)
    state = obj.add_round_key(keys[i])

#Last round does not include mix-column operation
state = obj.sub_bytes()
state = obj.shiftRows()
state = obj.add_round_key(keys[4])

print("\n")
print('-' * 100)

print("Ciphetext :\n")
print(state)
