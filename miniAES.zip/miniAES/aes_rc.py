def aes_round_constants(n):
    rcon = [2]  # Initialize Rcon with 2
    
    # Iterate to generate n-1 round constants
    for i in range(1, n):
        # Multiply previous value by 2 in the Galois Field (GF(16))
        value = rcon[-1] << 1
        
        # If value exceeds 255, perform modulo with x^4 + x + 1
        if value > 15:
            value ^= 0x13  # x^4 + x + 1
        
        # Append the result to the Rcon list
        rcon.append(value)
    
    return rcon

# Example usage:
round_constants = aes_round_constants(10)  # Generate 10 round constants
print("Round Constants:", round_constants)

