class miniAES_Encrypt:
    def __init__(self, state):
        self.state = state

    def mix_column(self):
        mix_matrix = [[3, 2], [2, 3]]
        result = [[0, 0], [0, 0]]  # Initialize the result matrix
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    # Accumulate the results in the result matrix
                    result[i][j] ^= self.gf_mult(mix_matrix[i][k], self.state[k][j])

        # Print or return the result matrix as needed
        return result
    
    # Galois Field Multiplication
    @staticmethod
    def gf_mult(a, b):  # Define gf_mult to accept two arguments
        p = 0
        for _ in range(4):  # Assuming 4-bit values
            if b & 1:
                p ^= a
            hi_bit_set = a & 0x8
            a <<= 1
            if hi_bit_set:
                a ^= 0x13   # Divisible by x^4 + x + 1
            b >>= 1
        return p


state = [[4, 13], [2, 1]]
obj = miniAES_Encrypt(state)
print(obj.mix_column())
