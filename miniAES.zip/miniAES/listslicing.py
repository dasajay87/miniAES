original_list = [1, 2, 3, 4]

# Break the original list into a list of lists
result = [original_list[i:i+2] for i in range(0, len(original_list), 2)]

print(result)

